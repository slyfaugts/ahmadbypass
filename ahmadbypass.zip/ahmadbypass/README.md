# AhmadBypass — Roblox Music Speed Tool
by AahmadSaltoria · saltoria community

## Deploy ke Vercel (Gratis)

### Cara 1 — Via GitHub (Recommended)

1. **Buat akun GitHub** di github.com (gratis)
2. **Buat repository baru** → klik tombol "+" → "New repository"
   - Nama: `ahmadbypass`
   - Visibility: Public atau Private (bebas)
3. **Upload semua file ini** ke repository:
   - Drag & drop folder `api/` dan `public/` dan `vercel.json`
4. **Buka vercel.com** → Login dengan GitHub
5. Klik **"Add New Project"** → Import repository `ahmadbypass`
6. Klik **Deploy** — selesai! 🎉

Website kamu akan live di: `https://ahmadbypass.vercel.app` (atau nama lain)

---

### Cara 2 — Via Vercel CLI

```bash
npm install -g vercel
cd ahmadbypass
vercel
```

---

## Struktur File

```
ahmadbypass/
├── api/
│   └── upload.js      ← Backend proxy ke Roblox API (bypass CORS)
├── public/
│   └── index.html     ← Frontend website
└── vercel.json        ← Konfigurasi Vercel
```

## Cara Pakai

1. Upload file audio (MP3/WAV/dll)
2. Pilih kecepatan (default 2.2x)
3. Klik "Ubah Kecepatan"
4. Download atau upload langsung ke Roblox

## Roblox API Key

Buat API key di: https://create.roblox.com/dashboard/credentials
- Tambahkan permission: `assets` → `asset:read` + `asset:write`
